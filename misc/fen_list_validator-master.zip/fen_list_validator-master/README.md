# fen_list_validator
> A simple command line utility for validating FEN records

The command `fenlistval` expects one or more file name arguments. The file names should have the suffix `.fen`. The files themselves should contain only FEN records separated by UNIX newline characters.
