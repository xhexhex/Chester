#include <stdio.h>
#include <stdbool.h>
#include <assert.h>

#include "fenlistval.h"

static int file_name_args_counter( int argc, char *argv[] );

int
main( int argc, char *argv[] )
{
	const int file_name_count = file_name_args_counter( argc, argv );

	if( file_name_count < 0 ) {
		fprintf( stderr, "ERROR: Invalid file name argument detected: %s\n",
			argv[ -file_name_count ] );
		return 1;
	}

	assert( file_name_count == argc - 1 );

	if( !file_name_count ) {
		fprintf( stderr, "ERROR: Received no file name arguments\n" );
		return 2;
	}

	return fenlistval( argc, argv );
}

// Apart from the first element, all elements of argv are assumed to be
// file name strings with the case-insensitive suffix ".fen". For example,
// xyz.fen and a.FEN are valid file names. If all arguments are found
// to be valid file names, file_name_args_counter() returns their number.
// Otherwise it returns a negative value. The additive inverse of this
// negative return value is the index of the invalid file name in argv.
static int
file_name_args_counter( int argc, char *argv[] )
{
	if( argc == 1 )
		return 0;

	int counter = 0;

	for( int i = 1; i < argc; i++ )
		if( str_matches_ere( argv[ i ],
				"^(.*/)?[-+._a-zA-Z0-9]+\\.[Ff][Ee][Nn]$" ) )
			++counter;
		else // Invalid file name argument detected
			return -i; // Always negative

	return counter;
}
