#ifndef FENLISTVAL_H
#define FENLISTVAL_H

#include <stdbool.h>
#include "chester.h"

#define MAX_FILE_COUNT 1000
#define MAX_LINE_LENGTH 100

struct test_result {
	char fen[ MAX_LINE_LENGTH + 1 ];
	enum fen_str_error error_code;
	int line_num;
};

bool str_matches_ere( const char *str, const char *ere );
int fenlistval( int argc, char *argv[] );

#endif
// end FENLISTVAL_H
