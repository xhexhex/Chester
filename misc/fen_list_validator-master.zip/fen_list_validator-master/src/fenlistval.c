#include <regex.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "fenlistval.h"

static int open_files( FILE *fpa[], char *fna[], int argc, char *argv[] );
static int close_files( FILE *fpa[], int file_count );
static int longest_line( const FILE * const fp, char newline, int *line_num );
static void process_file( const FILE * const fp, const char *file_name );
static void end_of_line_reached( char fen[], int *i,
	struct test_result *test_results[], int *current_line_num,
	int *num_valid_fens, int *num_invalid_fens );
static bool file_ends_in_newline( const FILE * const fp );
static int line_counter( const FILE * const fp );
static struct test_result *new_test_result(
	const char *fen, enum fen_str_error error_code, int line_num );
static void print_test_results( const char *file_name, int num_valid_fens,
	int num_invalid_fens, struct test_result *test_results[], int num_results );

int
fenlistval( int argc, char *argv[] )
{
	FILE *fpa[ MAX_FILE_COUNT ]; // fpa, file pointer array
	char *fna[ MAX_FILE_COUNT ]; // fna, file name array

	const int file_count = open_files( fpa, fna, argc, argv );
	int num_files_processed = 0;

	fprintf( stderr, "DEBUG: opened files: " );
	for( int i = 0; i < file_count; i++ ) {
		fprintf( stderr, "%s ", fna[ i ] );
	}
	fprintf( stderr, "\n" );

	int line_num;
	for( int i = 0; i < file_count; i++ ) {
		if( longest_line( fpa[ i ], '\n', &line_num ) <= MAX_LINE_LENGTH ) {
			if( file_ends_in_newline( fpa[ i ] ) ) {
				process_file( fpa[ i ], fna[ i ] );
				++num_files_processed;
			}
			else
				fprintf( stderr,
					"WARNING: Skipping %s: doesn't end in newline\n", fna[ i ] );
		}
		else {
			fprintf( stderr,
				"WARNING: Skipping file %s with line(s) over %d chars long\n",
				fna[ i ], MAX_LINE_LENGTH );
		}
	}

	assert( close_files( fpa, file_count ) == file_count );

	return num_files_processed ? 0 : 3;
}

// Returns true if 'str' matches the extended regular expression 'ere'
bool
str_matches_ere( const char *str, const char *ere )
{
	regex_t regex;
	int result;

	// Compile the regex and make sure it worked out
	assert( !regcomp( &regex, ere, REG_EXTENDED ) );

	// Testing if str matches the regular expression in regex.
	result = regexec( &regex, str, 0, NULL, 0 );
	// Making sure regexec() didn't run into problems
	assert( !result || result == REG_NOMATCH );

	return !result;
}

// Returns the number of successfully opened files
static int
open_files( FILE *fpa[], char *fna[], int argc, char *argv[] )
{
	FILE *fp;
	int num_of_files_opened = 0;

	for( int i = 1; i < argc && num_of_files_opened < MAX_FILE_COUNT; i++ ) {
		if( !( fp = fopen( argv[ i ], "rb" ) ) ) {
			fprintf( stderr, "WARNING: Failed to open file %s\n", argv[ i ] );
			continue;
		}

		fpa[ num_of_files_opened ] = fp;
		fna[ num_of_files_opened ] = argv[ i ];
		++num_of_files_opened;
	}

	return num_of_files_opened;
}

// Returns the number of successfully closed files
static int
close_files( FILE *fpa[], int file_count )
{
	int num_of_files_closed = 0;

	for( int i = 0; i < file_count; i++ ) {
		if( !fclose( fpa[ i ] ) )
			++num_of_files_closed;
	}

	return num_of_files_closed;
}

static int
longest_line( const FILE * const fp, char newline, int *line_num )
{
	rewind( (FILE *) fp );

	char c;
	int current = 0, longest = 0, current_line = 1;
	*line_num = current_line;

	while( true ) {
		if( current > longest ) {
			longest = current;
			*line_num = current_line;
		}

		c = getc( (FILE *) fp );

		if( feof( (FILE *) fp ) )
			break;
		else if( c == newline ) {
			current = 0;
			++current_line; }
		else
			++current;
	}

	return longest;
}

static void
process_file( const FILE * const fp, const char *file_name )
{
	char fen[ MAX_LINE_LENGTH + 1 ];
	int i = 0, num_valid_fens = 0, num_invalid_fens = 0,
		current_line_num = 1;

	const int line_count = line_counter( fp );
	rewind( (FILE *) fp );
	struct test_result *test_results[ line_count ];

	while( true ) {
		assert( i >= 0 && i <= MAX_LINE_LENGTH );

		char c = getc( (FILE *) fp );

		if( feof( (FILE *) fp ) )
			break;
		else if( c == '\n' ) {
			end_of_line_reached( fen, &i, test_results, &current_line_num,
				&num_valid_fens, &num_invalid_fens );
		}
		else {
			fen[ i ] = c;
			++i;
		}
	}

	assert( num_valid_fens + num_invalid_fens == line_count );

	print_test_results( file_name, num_valid_fens, num_invalid_fens,
		test_results, line_count );
}

static void
end_of_line_reached( char fen[], int *i, struct test_result *test_results[],
	int *current_line_num, int *num_valid_fens, int *num_invalid_fens )
{
	fen[ *i ] = '\0';
	assert( strlen( fen ) <= MAX_LINE_LENGTH );

	// Calling che_validate_fen_str() is what this program is
	// all about, really
	enum fen_str_error error_code = che_validate_fen_str( fen );

	test_results[ *current_line_num - 1 ] =
		new_test_result( fen, error_code, *current_line_num );
	*current_line_num += 1;

	if( !error_code )
		*num_valid_fens += 1;
	else
		*num_invalid_fens += 1;

	*i = 0;
}

static bool
file_ends_in_newline( const FILE * const fp )
{
	rewind( (FILE *) fp );
	int file_size = 0;

	while( true ) {
		getc( (FILE *) fp );

		if( feof( (FILE *) fp ) )
			break;
		else
			++file_size;
	}

	if( !file_size )
		return false;

	fseek( (FILE *) fp, -1, SEEK_END );
	return getc( (FILE *) fp ) == '\n';
}

static int
line_counter( const FILE * const fp )
{
	rewind( (FILE *) fp );

	char c;
	int line_count = 0;

	while( ( c = getc( (FILE *) fp ) ) != EOF )
		if( c == '\n' )
			++line_count;

	return line_count;
}

static struct test_result *
new_test_result( const char *fen, enum fen_str_error error_code, int line_num )
{
	struct test_result *tr =
		(struct test_result *) malloc( sizeof(struct test_result) );

	strcpy( tr->fen, fen );
	tr->error_code = error_code;
	tr->line_num = line_num;

	return tr;
}

static void
print_test_results( const char *file_name, int num_valid_fens,
	int num_invalid_fens, struct test_result *test_results[], int num_results )
{
	printf( "%s: %d valid, %d invalid FENs detected\n",
		file_name, num_valid_fens, num_invalid_fens );

	for( int i = 0; i < num_results; i++ ) {
		enum fen_str_error ec = test_results[ i ]->error_code;

		if( ec )
			printf( "Line %d: Error code %d: \"%s\"\n",
				test_results[ i ]->line_num, ec, test_results[ i ]->fen );

		free( test_results[ i ] );
	}
}
