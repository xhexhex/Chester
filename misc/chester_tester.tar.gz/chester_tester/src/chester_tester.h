#ifndef CHESTER_TESTER_H
#define CHESTER_TESTER_H

#include <stdbool.h>
#include "chester.h"

void say_hello();
void call_che_rawcodes();

#endif
// end CHESTER_TESTER_H
