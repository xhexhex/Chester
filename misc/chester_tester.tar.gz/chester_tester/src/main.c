#include <stdio.h>
#include <stdbool.h>
#include <assert.h>

#include "chester_tester.h"

int
main()
{
    say_hello();
    call_che_rawcodes();
}
