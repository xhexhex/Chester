#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

#include "chester_tester.h"

void
say_hello()
{
    printf( "Hello!\n" );
}

void
call_che_rawcodes()
{
    Rawcode *codes = che_rawcodes(
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" );

    Rawcode *ptr = codes;
    while( *ptr ) {
        printf( "Rawcode: %d\n", *ptr );
        ++ptr;
    }

    assert( *ptr == 0 );

    free(codes);
}
